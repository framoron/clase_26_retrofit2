package com.example.clase26retrofit2

import com.google.gson.annotations.SerializedName

data class DogsResponse(
    @SerializedName("message")  var images: List<String>,
//    @SerializedName("status")
    var status:String
    )

//es obligatorio que los nombres de los parámetros sean iguales que los nombres de los campos
//del Json para poder obtener la información.

